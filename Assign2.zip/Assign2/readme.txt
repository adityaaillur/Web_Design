<html>	Defines an HTML document
<head>	Contains metadata/information for the document
<title>	Defines a title for the document
<body>	Defines the document's body
<h1> to <h6>	Defines HTML headings
<p>	Defines a paragraph
<br>	Inserts a single line break
<hr>	Defines a thematic change in the content
<img>	Defines an image
<ul>
<li>
<nav>
<footer>
<header>
<main>
<h1> to <h6>
<span>
@media query -  to make it responsive
