Main Website: file:///Users/adityaillur/Documents/Masters/WEB/Assignments/Assign1/assign%201a/travel.html

Tags Used:
1. Head
2. Body
3. Division
4. Header
5. Image
6. Navigation
7. Unlisted
8. Listed
9. Anchor
10. Audio
11. Video
12. Footer
13. Hyperlink
14. Table