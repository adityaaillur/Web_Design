Sony headphone(WH-1000XM4), masterpiece is a beautifully crafted and adaptable product theme, HTML CSS Theme offers you cleverly optimized page layouts and sections so you can quickly build a gorgeous product store for a single product. It features a simple, contemporary design that quickly gives your website a polished appearance.

Main Website: http://127.0.0.1:5500/assign%201b/head.html

Tags Used:
1. Head
2. Body
3. Division
4. Header
5. Image
6. Navigation
7. Unlisted
8. Listed
9. Anchor
10. Audio
11. Video
12. Footer
13. Hyperlink