import React from 'react'
import Card from './Components/Card'

function About() {
  return (
    <div>
      <Card 
      src = "https://res.cloudinary.com/dj98golzx/image/upload/v1669067054/sony_logo_ogrclf.png"
      title="It's just you and your music with the WH-1000XM4 headphones.
      The easy way to enjoy less noise and even purer sound, with smart listening technology that 
      automatically personalises your experience. 
      42.4MP1 full-frame Exmor R™ CMOS sensor and BIONZ X processor
      Real-time AF tracking and Real-time Eye-AF9 for humans and animals
      Wide dynamic range, 14-bit uncompressed RAW11, ISO 50 to 102,4005
      Fast Hybrid autofocus: 399 phase-detection / 425 contrast AF points
      Up to 10fps2 continuous shooting at 42.4MP1 with AE/AF tracking
      5-axis image stabilization with 5.5-stop exposure advantage6
      3.69 million-dot1 OLED EVF / 2.35 million-dot1 tiltable 3” LCD monitor
      Secure and versatile dual media slots (1 SD card slot UHS-II compatible)
      Robust magnesium alloy body w/ dust and moisture resistant sealing8
      Super speed USB Type-C™ (USB 3.2 Gen compatible) and Micro USB"/>
    </div>
  )
}

export default About
