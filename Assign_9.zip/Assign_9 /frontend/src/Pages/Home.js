import React from 'react'
import Card from './Components/Card'

function Home() {
  const imageUrls = [
    {
        id: 1,
        url: "https://res.cloudinary.com/dj98golzx/image/upload/v1669059051/Sony3_lnatyf.jpg",
        title: "Mirrorless",
    },
    {
        id: 2,
        url: "https://res.cloudinary.com/dj98golzx/image/upload/v1669059051/Sony4_zmhqrp.jpg",
        title: "Sony A7 R V"
    },
    {
        id: 3,
        url: "https://res.cloudinary.com/dj98golzx/image/upload/v1669059051/Sony2_hbc85z.jpg",
        title: "Sony Alpha 7R V"
    },

];
  return (
    <div>
      {imageUrls.map(imageUrl => (<Card
        key = {imageUrl.id}
        src = {imageUrl.url}
        title = {imageUrl.title}
        description = {imageUrl.description}
      />))}
    </div>
  )
}

export default Home
