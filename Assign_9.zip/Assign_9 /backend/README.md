Aditya Illur - 002776756

Created both front end and backend

Backend - Using node, User login (Post) operation can be performed

Validation is used for the email, name and password too.

Front End - login.jsx file is created. 

function used to login:
const handleSubmit = () =>{
        fetch("http://localhost:8089/user/login",{
            method:"POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }

The Pages are created using React. User must Login using the credentials created through backend.
