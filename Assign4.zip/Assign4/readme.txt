NUID - 002776756

1. Validated the First Name, Last Name, Email, Phone number, address, city, state and zipcode with regex.
2. Restricting the Email id for @northeastern.edu along with prefix constraints.
3. adding the validations for form.
4. Showing the red colour along the text fields with red colour and making it diappearing on entering the fields.
5. creating the select list with 5 elements.
6. OnChange event for the list and which adds the checkbox dynamically for each selection.
7. if anything is missing in the text field is mandatory and it should disappear.
8. Creating the html table which collects the details after submitting the form.
9. On submitting the form the fields getting cleared out.
10.Street address 2 is not a mandatory field so not applying any constrsints and making it blank even if the field  is blank.
