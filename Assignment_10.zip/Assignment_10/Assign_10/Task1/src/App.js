import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
// import React from 'react';
import Counter from './container/counterContainer';
// import Counter from './reduxCounter';

class App extends Component{
  render(){
    return(
      <div clasNAme="App">
        <header className = "App-header">
        <Counter/>
        </header>        
      </div>
    )
  }
}
export default App;

